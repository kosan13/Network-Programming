using System;
using TMPro;
using Unity.Collections;
using Unity.Netcode;
using UnityEngine;

public class Chat : NetworkBehaviour
{
    [SerializeField] private InputReader inputReader;
    [SerializeField] private GameObject textPrefab;
    [SerializeField] private GameObject chat;
    [SerializeField] private GameObject chatGrid;
    [SerializeField] private TMP_InputField inputField;

    private void Start()
    {
        if (inputReader != null)
        {
            inputReader.OpenChat += OnOpenChat;
            inputReader.SendEvent += LocalSubmitMessage;
        }
    }
    private void OnOpenChat()
    {
        if (chat.activeSelf)
            chat.SetActive(false);
        else
        {
            chat.SetActive(true);
            inputField.Select();
        }
    }

    private void LocalSubmitMessage()
    {
        FixedString64Bytes fixedString = inputField.text;
        inputField.text = String.Empty;
        inputField.Select();
        SubmitMessageRPC(fixedString);
    }
    [Rpc(SendTo.Server)]
    private void SubmitMessageRPC(FixedString64Bytes message)
    {
        OnSendEventRPC(message);
    }

    [Rpc(SendTo.Everyone)]
    private void OnSendEventRPC(FixedString64Bytes message)
    {
        
        
        if (string.IsNullOrWhiteSpace(message.ToString())) return;
        
        GameObject curentMessage = Instantiate(textPrefab, chatGrid.transform);
        curentMessage.GetComponent<TMP_Text>().text = message.ToString();
    }
}
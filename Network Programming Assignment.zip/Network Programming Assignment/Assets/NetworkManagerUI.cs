using Unity.Netcode;
using UnityEngine;

public class NetworkManagerUI : MonoBehaviour
{
    [SerializeField] private NetworkManager networkManager;
    [SerializeField] private GameObject mainCamera;
    private void OnGUI()
    {
        if (GUILayout.Button("Host"))
        {
            mainCamera.SetActive(false);
            networkManager.StartHost();
        }
        if (GUILayout.Button("Join"))
        {
            mainCamera.SetActive(false);
            networkManager.StartClient();
        }
        if (GUILayout.Button("back"))
        {
            mainCamera.SetActive(true);
            networkManager.Shutdown();
        }
        if (GUILayout.Button("Quit"))
        {
            Application.Quit();
        }
    }
}
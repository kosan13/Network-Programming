using Unity.Netcode;
using UnityEngine;

public class Shooter : NetworkBehaviour
{
    [SerializeField] private InputReader inputReader;
    [SerializeField] private GameObject bulletToSpawn;
    [SerializeField] private Camera playerCamera;
    
    private void Start()
    {
        if (inputReader != null)
        {
            inputReader.ShootEvent += LocalOnShoot;
        }
    }

    private void LocalOnShoot()
    {
        Vector3 mousePosition = Input.mousePosition;
        Vector3 worldPosition = playerCamera.ScreenToWorldPoint(mousePosition);
        SpawnBulletRPC(worldPosition);
    }
    
    [Rpc(SendTo.Server)]
    private void SpawnBulletRPC(Vector3 mousePosition)
    {
        NetworkObject bulletObject = Instantiate(bulletToSpawn, transform).GetComponent<NetworkObject>();
        bulletObject.Spawn();
        bulletObject.GetComponent<Bullet>().AddForesToBullet(mousePosition);
    }
}

using Unity.Netcode;
using UnityEngine;
using UnityEngine.Serialization;

public class Player : NetworkBehaviour
{
    [SerializeField] private InputReader inputReader;
    private readonly NetworkVariable<Vector3> _moveInput = new();
    [SerializeField] private GameObject playerCamera;
    [SerializeField] private float speed = 10;

    private void Awake()
    {
        playerCamera.SetActive(false);
    }
    private void Start()
    {
        if (inputReader != null && IsLocalPlayer)
        {
            inputReader.MoveEvent += OnMove;
        }
        if (IsLocalPlayer)
        {
            playerCamera.SetActive(true);
        }
    }
    private void OnMove(Vector2 input)
    {
        HelloRPC(input);
    }
    private void Update()
    {
        if (IsServer)
        {
            transform.position += _moveInput.Value * (Time.deltaTime * speed);
        }
    }
    [Rpc(SendTo.Server)]
    private void HelloRPC(Vector2 data)
    {
        _moveInput.Value = data;
    }
}

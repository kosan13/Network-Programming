using Unity.Netcode;
using UnityEngine;

public class Bullet : NetworkBehaviour
{
    [SerializeField] private float bulletLifeTime = 10f;

    private void Update()
    {
        if (!IsServer) return;
        if (bulletLifeTime > 0)
        {
            bulletLifeTime--;
        }
        else
        {
            NetworkObject.Despawn(true);
        }
    }

    public void AddForesToBullet(Vector3 endPosition)
    {
        Vector2 temp = new Vector2(endPosition.x, endPosition.y);

        GetComponent<Rigidbody2D>().velocity = temp.normalized;
        AddForesToBulletRPC(temp);
    }

    [Rpc(SendTo.ClientsAndHost)]
    public void AddForesToBulletRPC(Vector2 endPosition)
    {
        if(IsHost) return;
        GetComponent<Rigidbody2D>().velocity = endPosition.normalized;
    }
}
